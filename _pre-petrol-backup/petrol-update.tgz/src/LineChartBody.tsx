import React from "react";
import {
  DataRow,
  Waypoint,
  buildRuns,
  chooseYStep,
  haFor,
  monthDate,
  pathD,
  px,
  py,
  svgAnchor,
  yearStep,
} from "./chartEngine";
import { MARK, PETROL, Palette, PLOT, ROW, STROKE, TYPE } from "./theme";

// The reusable "line reveals, comet dot rides the tip, waypoints pop in and
// shrink with zoom" body -- shared by the reveal-only and zoom-out
// compositions. Everything is plain SVG/JSX so it renders identically whether
// zoomFactor is 1 (no zoom) or >1 (zoomed out).
//
// Three changes from the first version, all visual -- the data, the waypoint
// dates, the y-limits and the gap handling are untouched:
//   1. The x-axis moved above the plot, bound to it by a rule and tick marks.
//      Same plot height either way; the point is that year labels can no longer
//      collide with the caption block.
//   2. The glow filter is gone. A knockout stroke -- the path drawn first at
//      21px in the background color, then at 11px in the series color -- keeps
//      the line clean where it crosses gridlines with none of the neon.
//   3. The latest point is a filled accent square rather than another circle,
//      so "now" is distinguishable from the annotated historical points. This
//      is the single use of the accent color in the frame.
export const LineChartBody: React.FC<{
  data: DataRow[];
  xDomain: [number, number];
  yDomain: [number, number];
  i0: number;
  tipExact: number;
  waypoints: Waypoint[];
  zoomFactor?: number;
  palette?: Palette;
}> = ({ data, xDomain, yDomain, i0, tipExact, waypoints, zoomFactor = 1, palette = PETROL }) => {
  const yStep = chooseYStep(yDomain);
  const yTicks: number[] = [];
  for (let yv = Math.ceil(yDomain[0] / yStep) * yStep; yv <= yDomain[1]; yv += yStep) yTicks.push(yv);

  const iLo = Math.max(0, Math.ceil(xDomain[0]));
  const iHi = Math.min(data.length - 1, Math.floor(xDomain[1]));
  const step = yearStep(xDomain);
  const janIdxs: number[] = [];
  for (let i = iLo; i <= iHi; i++) {
    const md = monthDate(data[i].date);
    if (md.month === 1 && md.year % step === 0) janIdxs.push(i);
  }

  const { runs, tipVal } = buildRuns(data, i0, tipExact);
  const d = pathD(runs, xDomain, yDomain);

  const lastIdx = data.length - 1;
  const atLatest = tipExact >= lastIdx - 1e-9;

  return (
    <>
      {/* horizontal gridlines + y labels */}
      {yTicks.map((yv) => {
        const yPix = py(yv, yDomain);
        return (
          <React.Fragment key={`y-${yv}`}>
            <line
              x1={PLOT.left}
              y1={yPix}
              x2={PLOT.right}
              y2={yPix}
              stroke={palette.grid}
              strokeWidth={STROKE.grid}
            />
            <text
              x={PLOT.left - 22}
              y={yPix + 14}
              fontSize={TYPE.axis.size}
              fontFamily={TYPE.axis.family}
              fontWeight={TYPE.axis.weight}
              fill={palette.dim}
              textAnchor="end"
            >
              {yv}
            </text>
          </React.Fragment>
        );
      })}

      {/* x-axis, ABOVE the plot: rule + ticks bind the year labels to the plot
          so they read as an axis rather than as a subtitle under the title. */}
      <line
        x1={PLOT.left}
        y1={ROW.xaxisRule}
        x2={PLOT.right}
        y2={ROW.xaxisRule}
        stroke={palette.grid}
        strokeWidth={STROKE.grid}
      />
      {janIdxs.map((i) => (
        <React.Fragment key={`x-${i}`}>
          <line
            x1={px(i, xDomain)}
            y1={ROW.xaxisRule}
            x2={px(i, xDomain)}
            y2={ROW.xaxisRule + ROW.xaxisTick}
            stroke={palette.grid}
            strokeWidth={STROKE.tick}
          />
          <text
            x={px(i, xDomain)}
            y={ROW.xaxisLabel}
            fontSize={TYPE.axis.size}
            fontFamily={TYPE.axis.family}
            fontWeight={TYPE.axis.weight}
            fill={palette.dim}
            textAnchor="middle"
          >
            {`’${String(monthDate(data[i].date).year).slice(2)}`}
          </text>
        </React.Fragment>
      ))}

      {/* the series: knockout stroke, then the real one */}
      {d && (
        <>
          <path
            d={d}
            fill="none"
            stroke={palette.bg}
            strokeWidth={STROKE.knockout}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d={d}
            fill="none"
            stroke={palette.series}
            strokeWidth={STROKE.series}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </>
      )}

      {/* leading edge, only while the line is still drawing */}
      {tipVal && !atLatest && (
        <>
          <circle
            cx={px(tipVal[0], xDomain)}
            cy={py(tipVal[1], yDomain)}
            r={(MARK.waypoint + 2) / zoomFactor}
            fill={palette.series}
          />
          <circle
            cx={px(tipVal[0], xDomain)}
            cy={py(tipVal[1], yDomain)}
            r={MARK.waypointCore / zoomFactor}
            fill={palette.bg}
          />
        </>
      )}

      {waypoints
        .filter((wp) =>
          wp.idx >= i0 ? tipExact >= wp.idx : xDomain[0] <= wp.idx && wp.idx <= xDomain[1]
        )
        .map((wp) => {
          const cx = px(wp.idx, xDomain);
          const cy = py(wp.val, yDomain);
          const anchor = svgAnchor(haFor(wp.idx, xDomain));
          const isLatest = wp.idx === lastIdx;
          const s = MARK.latest / zoomFactor;
          return (
            <React.Fragment key={`wp-${wp.idx}`}>
              {isLatest ? (
                <rect
                  x={cx - s / 2}
                  y={cy - s / 2}
                  width={s}
                  height={s}
                  rx={MARK.radius / zoomFactor}
                  fill={palette.accent}
                />
              ) : (
                <>
                  <circle cx={cx} cy={cy} r={MARK.waypoint / zoomFactor} fill={palette.series} />
                  <circle cx={cx} cy={cy} r={MARK.waypointCore / zoomFactor} fill={palette.bg} />
                </>
              )}
              <text
                x={cx}
                y={py(wp.calloutYDate, yDomain)}
                fontSize={TYPE.date.size / zoomFactor}
                fontFamily={TYPE.date.family}
                fontWeight={TYPE.date.weight}
                fill={palette.dim}
                textAnchor={anchor}
              >
                {wp.dateLabel}
              </text>
              <text
                x={cx}
                y={py(wp.calloutYValue, yDomain)}
                fontSize={TYPE.value.size / zoomFactor}
                fontFamily={TYPE.value.family}
                fontWeight={TYPE.value.weight}
                fill={isLatest ? palette.accent : palette.text}
                textAnchor={anchor}
              >
                {wp.valueLabel}
              </text>
            </React.Fragment>
          );
        })}
    </>
  );
};
